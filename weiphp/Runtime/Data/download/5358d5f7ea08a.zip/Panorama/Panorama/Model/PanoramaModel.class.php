<?php

namespace Addons\Panorama\Model;
use Think\Model;

/**
 * Panorama模型
 */
class PanoramaModel extends Model{

}
